from src.graph import Graph

g = Graph(True)