Graph Problems

- Checkerboard Covering: How do you cover a checkerboard with one corner missing using L shaped (two squares in one direction and one square in the perpendicular direction) tiles?
- Knight's Tour: Find a sequence of moves for a knight on a chessboard so that the knight visits every square on the chessboard exactly once.  This sequence is called a "tour".
