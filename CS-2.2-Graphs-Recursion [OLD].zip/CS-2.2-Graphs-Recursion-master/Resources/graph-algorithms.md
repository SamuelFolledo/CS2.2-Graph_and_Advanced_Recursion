## Graph Algorithms

- **Shortest Path with BFS: **
- **Dijkstra's Algorithm: **
- **Prim's Algorithm:**
- **Handshake Lemma:**
